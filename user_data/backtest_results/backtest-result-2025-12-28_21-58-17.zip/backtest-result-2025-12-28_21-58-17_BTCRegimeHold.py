# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# flake8: noqa: F401
# isort: skip_file

"""
BTC Regime Hold Strategy
========================
True implementation of the 200MA regime strategy.

Core Principle:
- Enter ONCE when price crosses ABOVE the MA (bull regime starts)
- Hold position until price crosses BELOW the MA (bear regime starts)
- Use FULL CAPITAL with 2x leverage during bull regime
- Stay in cash during bear regime

This is NOT an active trading strategy - it's a regime filter.
Expected: ~5-15 trades over 3 years (one per major regime change)
"""

import numpy as np
import pandas as pd
from datetime import datetime
from typing import Optional

from freqtrade.strategy import IStrategy, IntParameter, DecimalParameter
from pandas import DataFrame
import talib.abstract as ta


class BTCRegimeHold(IStrategy):
    """
    True 200MA Regime Strategy - Hold during bull, cash during bear.

    Key differences from active trading:
    - Only enters on MA crossover (not when simply above)
    - Only exits on MA crossunder (not on other signals)
    - Uses 100% capital, not fixed stake
    - Disables ROI and trailing stop to let position run
    """

    INTERFACE_VERSION = 3

    # MA period - classic 200 period for regime detection
    ma_period = IntParameter(150, 250, default=200, space="buy", optimize=True)

    # Buffer to avoid whipsaws at MA crossover
    cross_buffer = DecimalParameter(0.005, 0.03, default=0.01, space="buy", optimize=True)

    # CRITICAL: Disable ROI - we want to hold the entire bull run
    minimal_roi = {
        "0": 100.0,  # 10000% - effectively disabled
    }

    # Wide stop loss - trust the MA exit, not arbitrary stop
    stoploss = -0.25

    # DISABLE trailing stop - we don't want early exits
    trailing_stop = False

    # Timeframe
    timeframe = '4h'

    # Long only - no shorting in bear market (just cash)
    can_short = False

    # Startup candle count
    startup_candle_count = 250

    # Order types
    order_types = {
        'entry': 'limit',
        'exit': 'limit',
        'stoploss': 'market',
        'stoploss_on_exchange': True,
    }

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """Calculate MA and crossover signals."""

        # Calculate all MA periods for hyperopt
        for period in range(150, 251):
            dataframe[f'ma_{period}'] = ta.SMA(dataframe, timeperiod=period)

        # Standard 200 MA for reference
        dataframe['ma_200'] = ta.SMA(dataframe, timeperiod=200)

        # EMA 200 for faster response option
        dataframe['ema_200'] = ta.EMA(dataframe, timeperiod=200)

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Enter ONLY when price crosses above MA (regime change to bull).
        This should happen rarely - only at major turning points.
        """

        ma_col = f'ma_{self.ma_period.value}'
        buffer_mult = 1 + self.cross_buffer.value

        # CROSSOVER: Price was below MA, now above MA * buffer
        # This should only trigger at the START of a new bull regime
        dataframe.loc[
            (
                (dataframe['close'].shift(1) <= dataframe[ma_col].shift(1)) &  # Was below/at MA
                (dataframe['close'] > dataframe[ma_col] * buffer_mult) &  # Now above MA + buffer
                (dataframe['volume'] > 0)
            ),
            'enter_long'] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Exit ONLY when price crosses below MA (regime change to bear).
        """

        ma_col = f'ma_{self.ma_period.value}'
        buffer_mult = 1 - self.cross_buffer.value

        # CROSSUNDER: Price was above MA, now below MA * buffer
        dataframe.loc[
            (
                (dataframe['close'].shift(1) >= dataframe[ma_col].shift(1)) &  # Was above/at MA
                (dataframe['close'] < dataframe[ma_col] * buffer_mult)  # Now below MA - buffer
            ),
            'exit_long'] = 1

        return dataframe

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: Optional[str],
                 side: str, **kwargs) -> float:
        """2x leverage during bull regime as per research."""
        return 2.0

    def custom_stake_amount(self, pair: str, current_time: datetime, current_rate: float,
                            proposed_stake: float, min_stake: Optional[float],
                            max_stake: float, leverage: float, entry_tag: Optional[str],
                            side: str, **kwargs) -> float:
        """
        Use FULL available capital during bull regime.
        This is the key difference - 100% invested, not just $100.
        """
        # Use 95% of available capital (leave some buffer)
        return max_stake * 0.95

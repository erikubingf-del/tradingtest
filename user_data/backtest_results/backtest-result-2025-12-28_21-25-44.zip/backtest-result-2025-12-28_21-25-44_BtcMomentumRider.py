# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# flake8: noqa: F401
# isort: skip_file

import numpy as np
import pandas as pd
from freqtrade.strategy import IStrategy
from freqtrade.strategy import stoploss_from_open
from pandas import DataFrame
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib

class BtcMomentumRider(IStrategy):
    """
    BTC Momentum Rider Strategy
    - Timeframe: 4h
    - Trend: EMA(50)
    - Momentum: RSI(14)
    - Volume: SMA(20) * 1.5
    """
    INTERFACE_VERSION = 3

    # ROI table: "time_in_minutes": "profit_ratio"
    # Exit after 4% profit immediately, or take smaller profits over time
    minimal_roi = {
        "0": 0.04,      # 4% profit
        "30": 0.02,     # 2% profit after 30 mins (if stuck)
        "60": 0.01      # 1% profit after 60 mins
    }

    # Stoploss: 2%
    stoploss = -0.02

    # Trailing stop: turned on to lock in profits
    trailing_stop = True
    trailing_stop_positive = 0.01  # Lock in at 1%
    trailing_stop_positive_offset = 0.02  # Trigger trailing when 2% profit reached
    trailing_only_offset_is_reached = True

    # Timeframe
    timeframe = '4h'

    # Indicators configuration
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # EMA for trend
        dataframe['ema_50'] = ta.EMA(dataframe, timeperiod=50)

        # RSI for momentum
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)

        # Volume MA
        dataframe['volume_mean'] = dataframe['volume'].rolling(window=20).mean()

        return dataframe

    # Entry Logic
    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Debugging: Force Entry to check if backtest engine works
        dataframe.loc[
            (
                (dataframe['rsi'] < 100)  # ALWAYS TRUE
            ),
            'enter_long'] = 1

        dataframe.loc[
            (
                (dataframe['rsi'] > 0)   # ALWAYS TRUE
            ),
            'enter_short'] = 1
            
        return dataframe

    # Exit Logic (Standard ROI/Stoploss handles most, but we can add indicators)
    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe['close'] < dataframe['ema_50']) & # Trend broke
                (dataframe['rsi'] > 70) # Became overbought while crashing?
            ),
            'exit_long'] = 1

        dataframe.loc[
            (
                (dataframe['close'] > dataframe['ema_50']) & # Trend broke
                (dataframe['rsi'] < 30)
            ),
            'exit_short'] = 1
            
        return dataframe

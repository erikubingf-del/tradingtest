from freqtrade.strategy import IStrategy, IntParameter, DecimalParameter, stoploss_from_open
from pandas import DataFrame
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib

class BTCRegimeHold(IStrategy):
    """
    BTC Regime Hold Strategy
    - Logic: 
        - Enter when price > MA(233) * 1.005
        - Exit when price < MA(233)
        - Leverage: 2x (Implied in analysis, not code)
    """
    INTERFACE_VERSION = 3
    can_short = False 

    # Parameters from User Claim
    ma_period = IntParameter(200, 300, default=233, space="buy")
    cross_buffer = DecimalParameter(0.001, 0.01, default=0.005, space="buy")

    # ROI: Hold forever (until exit signal)
    minimal_roi = {
        "0": 100.0 
    }

    # Stoploss: -25% (Wide)
    stoploss = -0.25 

    # Trailing stop: None mentioned, trusting MA
    trailing_stop = False

    # Timeframe: Switching to 1d for Verification
    timeframe = '1d'

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 1. Moving Average
        dataframe['ma_regime'] = ta.EMA(dataframe, timeperiod=self.ma_period.value)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe['close'] > dataframe['ma_regime'] * (1 + self.cross_buffer.value)) &
                (dataframe['volume'] > 0)
            ),
            'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe['close'] < dataframe['ma_regime']) 
            ),
            'exit_long'] = 1
        return dataframe
